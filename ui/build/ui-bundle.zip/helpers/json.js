'use strict'

module.exports = (obj) => JSON.stringify(obj)