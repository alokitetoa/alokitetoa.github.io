'use strict'

module.exports = (condition, page) => condition ? page.fileUri : page.editUrl